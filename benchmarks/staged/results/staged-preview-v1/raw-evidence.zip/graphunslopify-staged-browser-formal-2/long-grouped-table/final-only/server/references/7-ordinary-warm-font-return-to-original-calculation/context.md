Observed responses across the complete original experimental measurement period (D)

Observed response across the complete original experimental measurement period (fraction)

| Dataset | Base | Ours |
| --- | --- | --- |
| A | 0.60 | 0.80 |
| B | 0.70 | 0.90 |
