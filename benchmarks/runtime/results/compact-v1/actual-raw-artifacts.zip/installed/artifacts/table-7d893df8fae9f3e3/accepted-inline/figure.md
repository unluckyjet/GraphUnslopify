Cell bounds: estimate plus or minus one standard error

| Configuration | Top\-1 accuracy (%) |
| --- | --- |
| full | 81.80 [81.35, 82.25] |
| no augment | 77.70 [77.22, 78.19] |
| no distill | 76.38 [75.87, 76.88] |
| no both | 70.23 [69.92, 70.54] |
