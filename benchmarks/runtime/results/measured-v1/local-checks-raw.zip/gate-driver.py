"""Run required gates with explicit Python and unchanged executable/fixture bytes."""
import argparse
import datetime
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import time
from pathlib import Path

if not __debug__:
 raise RuntimeError('Run evidence guards without Python -O/PYTHONOPTIMIZE')
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--python',type=Path,required=True)
p.add_argument('--gallery',action='store_true')
a=p.parse_args();a.repo=a.repo.resolve();a.out=a.out.resolve();a.python=a.python.expanduser().absolute();a.out.mkdir(parents=True,exist_ok=False)
clt=Path('/Library/Developer/CommandLineTools/usr/bin/git');git=str(clt) if clt.is_file() else shutil.which('git')
if not git:raise RuntimeError('Git is required')
env=dict(os.environ);env['PYTHON']=str(a.python)
if clt.is_file():env['PATH']=str(clt.parent)+os.pathsep+env['PATH']
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def snapshot():
 names=set(subprocess.check_output([git,'ls-files','-z','--cached','--others','--exclude-standard'],cwd=a.repo).decode().split('\0'));result={}
 for name in sorted(names):
  if not name or '/results/' in name or name.endswith('.md') and name not in {'README.md','python/README.md'}:continue
  file=a.repo/name
  if file.is_file():result[name]=digest(file)
 return result
before=snapshot();(a.out/'tested-source-manifest.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,a.out/'gate-driver.py')
meta={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':str(a.python),'source_scope':'Tracked/untracked non-ignored files except Markdown narratives and derived /results/ folders; both package READMEs included. Includes code/config/fixtures/protocols/golden assets.','tracked_head_before':subprocess.check_output([git,'rev-parse','HEAD'],cwd=a.repo,text=True).strip(),'source_paths':len(before),'driver_sha256':digest(Path(__file__))};(a.out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
commands=[]
for line in (a.repo/'.github/workflows/checks.yml').read_text().splitlines():
 text=line.strip()
 if text.startswith('- run: ruff '):commands.append([str(a.python),'-m',*shlex.split(text.removeprefix('- run: '))])
if len(commands)!=2:raise RuntimeError('Expected the actual two complete CI Ruff invocations')
commands.extend([['npm','run','typecheck'],['npm','test'],['npm','run','test:python'],['npm','run','baseline','--','--check'],['npm','run','render-check'],['npm','run','recipe-check'],['npm','run','compose-check']])
if a.gallery:commands.append(['npm','run','gallery-check'])
receipts=[]
try:
 for i,command in enumerate(commands):
  if snapshot()!=before:raise RuntimeError('Source changed before gate '+str(i))
  start=time.monotonic()
  with (a.out/f'{i:02d}.log').open('w') as log:code=subprocess.call(command,cwd=a.repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  current=snapshot();changed=sorted(k for k in before.keys()|current.keys() if before.get(k)!=current.get(k));receipt={'command':command,'returncode':code,'seconds':time.monotonic()-start,'source_unchanged':not changed,'changed_paths':changed};receipts.append(receipt);(a.out/'gates.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipt),flush=True)
  if code or changed:raise RuntimeError('Gate failed or source changed; inspect '+str(a.out/f'{i:02d}.log'))
finally:
 (a.out/'gates.json').write_text(json.dumps(receipts,indent=2)+'\n')
