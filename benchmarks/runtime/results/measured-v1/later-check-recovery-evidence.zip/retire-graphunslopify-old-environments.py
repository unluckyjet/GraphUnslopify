"""Retire three exact superseded task venvs after source/dependency/PID evidence.

Historical narrow recipe. Keeps parent smoke outputs, current/minimum/no-package
environments and shared interpreter untouched. Third-party binaries are not
archived; dependency versions permit a proposed rebuild, not a tested restoration.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--apply', action='store_true')
p.add_argument('--cache', type=Path, required=True)
a = p.parse_args()
names = ['graphunslopify-spatial-backend-installed',
         'graphunslopify-heading-margin-installed',
         'graphunslopify-model-draft-installed']
probe = """import importlib.metadata as m,json,sys
print(json.dumps({'prefix':sys.prefix,'python':sys.version,
 'dependencies':sorted([(d.metadata['Name'],d.version) for d in m.distributions()]),
 'own_distribution_root':str(m.distribution('graphunslopify').locate_file('graphunslopify'))}))"""
rows = subprocess.check_output(['ps','-axo','pid=,command='], text=True).splitlines()
roots = [Path('/tmp') / name / 'fresh environment' for name in names]
for root in roots:
    assert root.is_dir() and not root.is_symlink() and (root/'pyvenv.cfg').is_file()
    aliases = [str(root), str(root.resolve())]
    assert not [s for s in rows if any(v in s for v in aliases)
                and int(s.strip().split(None,1)[0]) not in {os.getpid(),os.getppid()}]
if not a.apply:
    print(json.dumps({'eligible_exact_roots':[str(p) for p in roots]}))
    raise SystemExit(0)
a.cache.mkdir(parents=True, exist_ok=True)
receipt = {'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scope':__doc__, 'environments':[]}
for root in roots:
    completed = subprocess.run([str(root/'bin/python'),'-c',probe], cwd='/tmp',
        env={k:v for k,v in os.environ.items() if k!='PYTHONPATH'},
        capture_output=True, text=True, check=True)
    meta = json.loads(completed.stdout)
    assert Path(meta['prefix']).resolve() == root.resolve()
    package = Path(meta['own_distribution_root'])
    assert package.resolve().is_relative_to(root.resolve())
    target = a.cache / (root.parent.name + '-own-package.zip')
    assert not target.exists()
    files = {}
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for file in package.rglob('*'):
            if not file.is_file() or '__pycache__' in file.parts or file.suffix=='.pyc':
                continue
            assert not file.is_symlink()
            raw=file.read_bytes();name=str(file.relative_to(package))
            files[name]=hashlib.sha256(raw).hexdigest();z.writestr(name,raw)
        z.writestr('retirement-environment.json',json.dumps(meta,indent=2)+'\n')
        z.writestr('pyvenv.cfg', (root/'pyvenv.cfg').read_bytes())
    with zipfile.ZipFile(target) as z:
        assert all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in files.items())
    item={'root':str(root),'actual_environment':meta,'archive':str(target),
          'archive_bytes':target.stat().st_size,
          'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
          'own_package_files':files,'no_matching_active_process':True}
    receipt['environments'].append(item)
    (a.cache/'retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
    shutil.rmtree(root)
    item['retired']=True
    (a.cache/'retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'retired':[str(p) for p in roots]}))
