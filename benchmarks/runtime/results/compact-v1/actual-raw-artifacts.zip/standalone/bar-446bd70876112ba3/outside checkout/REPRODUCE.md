# Reproduce this figure

Use Python 3.10+ with the scientific dependencies in `_graphunslopify/requirements.txt`. The exact observed exporter environment is recorded separately; cross-version pixels may differ.

```sh
python -m pip install -r _graphunslopify/requirements.txt
python reproduce.py --json
```

GraphUnslopify's actual source runtime, inspection and licenses are included; no GraphUnslopify package installation or checkout is required. Third-party libraries are external dependencies, not vendored. MP4 outputs additionally need ffmpeg. Custom system fonts must also be available.

The launcher checks immutable program/runtime files and original inputs before executing the program with its original strict policy. Missing or modified input is rejected. Archived reference outputs have recorded hashes and are replaced by actual rerendering. A source archive is not a successful scientific verification result: run it and inspect its actual report/exit code. Integrity hashes do not authenticate authorship.
