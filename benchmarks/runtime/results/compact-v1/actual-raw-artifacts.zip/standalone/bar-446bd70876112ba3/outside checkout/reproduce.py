"""Run the archived figure with its actual included scientific runtime."""
import hashlib
import json
import os
import runpy
import sys
from pathlib import Path, PurePosixPath

root = Path(__file__).resolve().parent
manifest = json.loads((root / "_graphunslopify/manifest.json").read_text(encoding="utf8"))
def checked_path(name):
    relative = PurePosixPath(name)
    if relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
        raise RuntimeError("Invalid archived file path")
    path = root.joinpath(*relative.parts).resolve()
    if not path.is_relative_to(root):
        raise RuntimeError("Archived file escapes the bundle")
    return path
for name in manifest["immutable_files"]:
    expected = manifest["files"][name]
    path = checked_path(name)
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected["sha256"]:
        raise RuntimeError("Missing or modified archived file: " + name)
for expected in manifest["inputs"]:
    path = checked_path(expected["path"])
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected["sha256"]:
        raise RuntimeError("Supply the original unchanged input: " + expected["path"])
if "graphunslopify" in sys.modules:
    raise RuntimeError("Run this bundle in a fresh Python process")
sys.path.insert(0, str(root / "_graphunslopify/runtime"))
os.chdir(root)
runpy.run_path(str(checked_path(manifest["script"])), run_name="__main__")
